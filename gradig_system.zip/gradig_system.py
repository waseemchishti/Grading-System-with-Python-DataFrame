
student=int(input("Enter no of Student to add record: "))
print (student)
stt=[]
a=input("enter ")
print a+1
b=raw_input("enter")
print b
for a in range(student):
    # import re
    #
    # name_check=re.compile(r"[^A-Za-zs.]")
    #
    # name=raw_input("Please, enter your name: ")
    #
    # while name_check.search(name):
    #     print "Please enter your name correctly!"
    #     name=raw_input("Please, enter your name: ")
    #
    import re

    phone_check=re.compile(r"[^0-9s]")

    id=raw_input("Please, enter your phone: ")
    while phone_check.search(id):
            print "Please enter your phone correctly!"
            id=raw_input("Please, enter your phone: ")

    id=int(input("Enter Student Id: "))
    name=raw_input("Enter Student Name: ").title()
    marks=int(input("Enter Student Marks: "))
    grade='a'
    if marks<=50:
        grade="F"
    elif marks<=60:
        grade="D"
    elif marks<=70:
        grade="C"
    elif marks<=80:
        grade="B"
    else:
        grade="A"
#(b+": "+str(a)):
    a={'Id':id,'Name':name,'Marks':marks,'Grade':grade}

    stt.append(a)
    list=[1,2,3]
    #stt.append(st.items())
import pandas as pd
df=pd.DataFrame(stt)
print df[['Id','Name','Marks','Grade']]
n=input("Enter no to show Records")
print (df[['Name','Grade']].head(n))

#print (df['Name'])

#print stt
#name=input("Enter name odicf Student to show Marks: ")
#for a,b in st.items():
"""
for b in st.values():
        #print (a+": ")
        print ("Name: "+b['Name'], "Grade: "+b['Grade'])
#for c in b.values():
            #print c,d
#print ("Name: "+c['Name']+" Marks: ",c['Marks'])

a={
    'record1':{
    'id':1,
    'marks':50,
},
'record2':{
    'id':2,
    'marks':50,
}
}
"""
""""
for a in a.values():
    print a 
"""